module.exports = ["Liker","NiftyInk","NiftyMediator","NiftyRegistry","NiftyToken","NiftyToken","NiftyMain", "Nicknames"]
