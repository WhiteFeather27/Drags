import React from "react";
import { useParams } from "react-router-dom";
import { Query } from 'react-apollo'
import { ARTISTS_QUERY } from "./apollo/queries"



export default function Artist(props) {
   let { address } = useParams();

    return (
        <div>
          <h1>Artist: {address}</h1>
      <Query
        query={ARTISTS_QUERY}
        variables={{address: address}}
      >
        {({ data }) => {
          return (
            <div>
            <p>{JSON.stringify(data)}</p>
            </div>
          )
        }}
      </Query>
        </div>
    )
}
